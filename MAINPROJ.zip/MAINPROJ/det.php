
<html>
    <head>
        <meta charset="UTF-8">
        <title>user page</title>
         <link rel="stylesheet" type="text/css" href="stylesheet.css"/>
    </head>
    <body>
        <div class="u"><td>
                <h1><a class="p">ACCOUNT</a></h1></td>
        </div>
            <div class="u"><td>
                    <a href="addawards.php" class="u"><h4>Add awards</h4></a></td>
    </div>
         <div class="u"><td>
                 <a href="addalbs.php" class="u"><h4>Add Albums</h4></a></td>
    </div>
 
                    <div class="u"><td>
                    <a href="album.php" class="u"><h4>View albums</h4></a></td>
    </div>
                   <div class="u"><td>
                    <a href="message.php" class="u"><h4>View message</h4></a></td>
    </div>

              <div class="u"><td>
                    <a href="logout.php" class="u"><h4>logout</h4></a></td>
    </div>
          
        
    </body>
    
</html>


<html>
    <head>
        <meta charset="UTF-8">
        <title>CrAzY TuNeS- Home</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css"/>
    </head>
    <body>
        
    </body>
    <nav id="navigation">
                <ul id="nav">
                    <li><a href="artist.php">Artist</a></li>
                    <li><a class="p">CrAzY TuNeS</a></li>
                    <li><a href="user.php">Music</a></li>                  
                </ul>
        </nav>
    <div id="content_area">
        <h1><a class="v"> CrAzY TuNeS</a> </h1>
        <h1><a class="u">What is Music? Music is the ‘art of combining tones in a manner to please the ear’. </a></h1>
    </div>
     
             
                       
                                    <img src="images/mn.jpg" class="imgdown" />
                                     <img src="images/m1.jpg" class="imgdown2" />
                                      <img src="images/m2.jpg" class="imgdown" />
                                     <img src="images/m3.jpg" class="imgdown2" />
                                                                           
                                    
                                       
            
</html>


<html>
    <head>
        <meta charset="UTF-8">
        <title>user page</title>
         <link rel="stylesheet" type="text/css" href="stylesheet.css"/>
         <link rel="stylesheet" type="text/css" href="style.css"/>
    </head>
    <body>
        <div class="header">
            <h1> <a href="index.php" class="p">CrAzY TuNeS</a></h1>
	</div>
        
       <div class="u"><td>
            <a href="albs.php" class="p"><h2>View Albums</h2></a></td>
    </div>
            <div class="u"><td>
                    <a href="arts.php" class="p"><h2>View Artists</h2></a></td>
    </div>
          
             <div class="u"><td>
            <a href="msg.php" class="p"><h2>Leave a message</h2></a></td>
    </div>
        
    </body>
    
</html>
